// src/tooling/postinstall/download-puppeteer.ts
import { execFileSync } from "child_process";
import fs from "fs";
import { createRequire } from "module";
import path from "path";
var require2 = createRequire(path.join(process.cwd(), "package.json"));
var HOST_ENV_VARS = ["PUPPETEER_DOWNLOAD_BASE_URL", "PUPPETEER_DOWNLOAD_HOST"];
function resolveBaseUrl() {
  for (const envVar of HOST_ENV_VARS) {
    const value = process.env[envVar];
    if (value) return value;
  }
  return void 0;
}
function isSkipDownloadEnvSet() {
  const value = process.env.PUPPETEER_SKIP_DOWNLOAD;
  if (!value) return false;
  return !["0", "false", "off"].includes(value.toLowerCase());
}
function isSkipDownloadConfigured() {
  const searchRoot = process.env.INIT_CWD || process.cwd();
  const configPath = path.join(searchRoot, ".puppeteerrc.cjs");
  if (!fs.existsSync(configPath)) return false;
  try {
    const config = require2(configPath);
    return config?.skipDownload === true;
  } catch {
    return false;
  }
}
function downloadChrome() {
  if (!isSkipDownloadEnvSet() && !isSkipDownloadConfigured()) {
    console.log(
      "[postinstall] Download autom\xE1tico do puppeteer n\xE3o foi desativado (PUPPETEER_SKIP_DOWNLOAD/.puppeteerrc.cjs); assumindo que o Chrome j\xE1 foi baixado por ele."
    );
    return;
  }
  const baseUrl = resolveBaseUrl();
  const args = ["browsers", "install", "chrome"];
  if (baseUrl) {
    console.log(
      `[postinstall] Host de download do Puppeteer configurado, baixando via: ${baseUrl}`
    );
    args.push(`--base-url=${baseUrl}`);
  } else {
    console.log(
      "[postinstall] Nenhuma vari\xE1vel de host encontrada, baixando Chrome do host padr\xE3o do Puppeteer."
    );
  }
  execFileSync("puppeteer", args, { stdio: "inherit" });
}
downloadChrome();
